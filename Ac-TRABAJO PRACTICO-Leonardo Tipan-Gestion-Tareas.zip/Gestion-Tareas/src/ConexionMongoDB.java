import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class ConexionMongoDB {
    // Puerto local de MongoDB
    private static final String URI = "mongodb://localhost:27017"; 
    // Nombre de la base de datos
    private static final String DB_NAME = "GestionTareas"; 

    public static MongoDatabase conectar() {
        try {
            MongoClient cliente = MongoClients.create(new ConnectionString(URI));
            MongoDatabase database = cliente.getDatabase(DB_NAME);
            System.out.println(" Conectado a MongoDB: " + DB_NAME);
            return database;
        } catch (Exception e) {
            System.err.println(" Error al conectar a MongoDB: " + e.getMessage());
            return null;
        }
    }

    public static void main(String[] args) {
        conectar(); // Prueba de conexión
    }
}
