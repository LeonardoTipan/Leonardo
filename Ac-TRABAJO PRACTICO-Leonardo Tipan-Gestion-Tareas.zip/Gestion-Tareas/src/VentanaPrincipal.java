import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private final JTextField txtTitulo;
    private final JTextArea txtDescripcion;
    private final JButton btnAgregar;
    private final JButton btnEliminar;
    private final JTable tablaTareas;
    private final DefaultTableModel modelo;
    
    private void agregarTarea() {
        
    // Datos ingresados por el usuario
    String titulo = txtTitulo.getText().trim();
    String descripcion = txtDescripcion.getText().trim();

    // MANEJO DE ERROR: Verificación de mensajes vacios 
    if (titulo.isEmpty() || descripcion.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // CONEXIÓN A MONGODB
    MongoDatabase db = ConexionMongoDB.conectar();
    if (db != null) {
        // Accede a la colección (tareas)
        MongoCollection<Document> coleccion = db.getCollection("tareas");

        // Crea un documento con los datos ingresados
        Document nuevaTarea = new Document("titulo", titulo)
                .append("descripcion", descripcion);

        // Inserta la tarea en la base de datos
        coleccion.insertOne(nuevaTarea);

        // Mensaje de confirmación
        JOptionPane.showMessageDialog(this, "Tarea agregada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Limpia los campos
        txtTitulo.setText("");
        txtDescripcion.setText("");

        cargarTareas();
    }
}


    // SECCIÓN 1: CARGA DE TAREAS
    private void cargarTareas() {
        // Conectar a la base de datos
        MongoDatabase db = ConexionMongoDB.conectar();
        
        if (db != null) {
            // Acceder a la colección (tareas)
            MongoCollection<Document> coleccion = db.getCollection("tareas");

            // Limpia la tablaa para cargar datos nuevos
            modelo.setRowCount(0);

            // Obtiene todas las tareas y agrega a la tabla
            for (Document doc : coleccion.find()) {
                String titulo = doc.getString("titulo");
                String descripcion = doc.getString("descripcion");
                modelo.addRow(new Object[]{titulo, descripcion});
            }
        }
    }
    
    
    // SECCIÓN 2: ELIMINACIÓN DE TAREAS
    private void eliminarTarea() {
    int filaSeleccionada = tablaTareas.getSelectedRow();

    // MANEJO DE ERROR: Verificación de selección de tareas
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona una tarea para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Obtener el nombre de la tarea seleccionada
    String tituloTarea = modelo.getValueAt(filaSeleccionada, 0).toString();

    MongoDatabase db = ConexionMongoDB.conectar();
    if (db != null) {
        // Acceder a la colección (tareas)
        MongoCollection<Document> coleccion = db.getCollection("tareas");

        // Eliminar la tarea basada en su título
        coleccion.deleteOne(new Document("titulo", tituloTarea));

        // Mensaje de confirmación
        JOptionPane.showMessageDialog(this, "Tarea eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        cargarTareas();
    }
}


    // INTERFAZ GRÁFICA
    public VentanaPrincipal() {
        setTitle("Gestión de Tareas");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Componentes 
        JLabel lblTitulo = new JLabel("Tema:");
        lblTitulo.setBounds(20, 20, 80, 25);
        add(lblTitulo);

        txtTitulo = new JTextField();
        txtTitulo.setBounds(100, 20, 200, 25);
        add(txtTitulo);

        JLabel lblDescripcion = new JLabel("Descripción:");
        lblDescripcion.setBounds(20, 60, 80, 25);
        add(lblDescripcion);

        txtDescripcion = new JTextArea();
        txtDescripcion.setBounds(100, 60, 350, 60);
        add(txtDescripcion);

        btnAgregar = new JButton("Agregar Tarea");
        btnAgregar.setBounds(100, 140, 150, 30);
        add(btnAgregar);

        modelo = new DefaultTableModel();
        modelo.addColumn("Tema");
        modelo.addColumn("Descripción");

        tablaTareas = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tablaTareas);
        scrollPane.setBounds(20, 180, 450, 150);
        add(scrollPane);

        btnEliminar = new JButton("Eliminar Tarea");
        btnEliminar.setBounds(300, 140, 150, 30);
        add(btnEliminar);

        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarTarea();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarTarea();
            }
        });

        setVisible(true);
        cargarTareas();
    }
}
