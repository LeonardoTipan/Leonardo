package vista;

import modelo.Producto;
import java.util.List;

public class VistaInventario {
    public void mostrarProductos(List<Producto> productos) {
        System.out.println("--------- Inventario Shop Web ----------");
        for (Producto p : productos) {
            System.out.println(p);
        }
        System.out.println("      ----------------------------");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}