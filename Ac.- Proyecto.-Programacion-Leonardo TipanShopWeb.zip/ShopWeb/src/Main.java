public class Main {
    public static void main(String[] args) {
        // Crear instancias del modelo, vista y controlador
        modelo.Inventario inventario = new modelo.Inventario();
        vista.VistaInventario vista = new vista.VistaInventario();
        controlador.ControladorInventario controlador = new controlador.ControladorInventario(inventario, vista);

        // Sección para agregar productos
        controlador.agregarProducto("Celular", 15, 1200.0);
        controlador.agregarProducto("Audifonos", 50, 14.0);
        controlador.agregarProducto("Cargador", 30, 35.0);
        controlador.agregarProducto("Parlante", 5, 320.0);
        
        // Mostrar inventario
        controlador.mostrarInventario();

        // Sección para actualizar cantidad de productos
        controlador.actualizarCantidad("Audifonos", 37);
        controlador.actualizarCantidad("Cargador", 12);


        // Mostrar inventario actualizado
        controlador.mostrarInventario();

        // Sección para eliminar un producto
        controlador.eliminarProducto("Cargador");

        // Mostrar el estado del inventario
        controlador.mostrarInventario();
    }
}

