package controlador;

import modelo.Inventario;
import modelo.Producto;
import vista.VistaInventario;

public class ControladorInventario {
    private Inventario inventario;
    private VistaInventario vista;

    public ControladorInventario(Inventario inventario, VistaInventario vista) {
        this.inventario = inventario;
        this.vista = vista;
    }

    public void agregarProducto(String articulo, int cantidad, double precio) {
        Producto producto = new Producto(articulo, cantidad, precio);
        inventario.agregarProducto(producto);
        vista.mostrarMensaje("Producto agregado: " + articulo);
    }

    public void eliminarProducto(String articulo) {
        inventario.eliminarProducto(articulo);
        vista.mostrarMensaje("Producto eliminado: " + articulo);
    }

    public void actualizarCantidad(String articulo, int cantidad) {
        inventario.actualizarCantidad(articulo, cantidad);
        vista.mostrarMensaje("Actualizacion de cantidad para: " + articulo);
    }

    public void mostrarInventario() {
        vista.mostrarProductos(inventario.getProductos());
    }
}