package modelo;

import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private List<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void eliminarProducto(String articulo) {
        productos.removeIf(p -> p.getArticulo().equals(articulo));
    }

    public void actualizarCantidad(String articulo, int cantidad) {
        for (Producto p : productos) {
            if (p.getArticulo().equals(articulo)) {
                p.setCantidad(cantidad);
                break;
            }
        }
    }

    public List<Producto> getProductos() {
        return productos;
    }
}