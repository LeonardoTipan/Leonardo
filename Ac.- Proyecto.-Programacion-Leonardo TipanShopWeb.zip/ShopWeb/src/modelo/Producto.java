package modelo;

public class Producto {
    private String articulo;
    private int cantidad;
    private double precio;

    public Producto(String articulo, int cantidad, double precio) {
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public String getArticulo() {
        return articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return articulo + " - Cantidad: " + cantidad + " - Precio: $" + precio;
    }
}